var bananaImg,obstacleImg,player_running,backgroundImg;
var obstacleGroup, foodGroup;
var ground, player, score, gameState; 


function preload(){
  backgroundImg = loadImage("jungle.png");
  player_running = 
  loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  
  
  
  bananaImg = loadImage("banana.png");
  obstacleImg = loadImage("stone.png");
  
  
  
  
  
  
}
function setup() {
  createCanvas(600, 200);
  
  ground = createSprite(200,20,400,10);
  ground.addImage("ground",backgroundImg);
  ground.x = ground.width/2;
  ground.velocityX = -2;
  ground.visible = false;
  
  player = createSprite(50,180,20,20);
  player.addAnimation("running",player_running);
  player.scale = 0.25;
  
  
}

if (gameState === END) {
function draw() {
  background(250)
  if (ground.x < 0){
    ground.x = ground.width/2;
  }
  player.collide(ground);
  
  if(foodGroup.isTouching(player)){
    score = score + 2
    destroyEach(foodGroup);
  }
  switch(score){
      case 10: player.scale = player.scale + 2;
      break;
      case 20: player.scale = player.scale + 2;
      break;
      case 30: player.scale = player.scale + 2;
      break;
      case 40:player.scale = player.scale + 2;
      break;
      default:break;
  }
  if(obstacleGroup.isTouching(player)&&player.scale >0.2){
   player.scale = 0.2 
  }
  if(obstacleGroup.isTouching(player)&&player.scale === 0.2){
     gameState = END
     }

  
  spawnFood();
  spawnStone();
  
  drawSprites();
  
  stroke ("white");
  textSize(20);
  fill(white);
  text("Score:"+ score, 500, 50);
  
  
  
}
}
function spawnFood(){
  if(frameCount%60 === 0){
     var food = createSprite(600,120,40,10);
     cloud.y = math.round(random(80,120));
    food.addImage(bananaImg);
    food.scale = 0.2;
    food.velocityX = -3;
    
    food.lifetime = 200;
    
    foodGroup.add(food)
    
     }
  
}

function spawnStone(){
 if (frameCount%60 === 0){
   var stone = createSprite(600,165,10,40);
   stone.velocityX = -4;
   
   stone.scale = 0.2;
   stone.lifetime = 300;
   
   obstacleGroup.add(stone)
   
   
   
   
   
   
 }
}